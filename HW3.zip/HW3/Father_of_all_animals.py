from abc import ABC, abstractmethod


class Father_animal(ABC):
    def __init__(self, name: str, weight: int):
        self.weight = weight
        if self.weight < 1:
            raise Exception("The weight < 0. This is impossible")
        self.name = name