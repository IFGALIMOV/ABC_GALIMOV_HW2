from abc import ABC, abstractmethod
from Father_of_all_animals import Father_animal

class Zver(Father_animal):
    food_sources = ["Uelse", "Peru", "Mountins of the sun", "Kamenogorsk"]

    def __init__(self, name: str, weight: int, food_source: int):
        super().__init__(name, weight)
        if 1 <= food_source <= len(self.food_sources):
            self.food_source = self.food_sources[food_source - 1]
        else:
            raise Exception(f"Not right{name}")

    def to_string(self) -> str:
        return f"ANIMAL {{ name = \"{self.name}\" weight = {self.weight}; food_source = {self.food_source}; metric = {self.get_metric()} }}"


class Bird(Father_animal):
    def __init__(self, name: str, weight: int, does_migrate: bool):
        super().__init__(name, weight)
        self.does_migrate = does_migrate

    def to_string(self) -> str:
        return f"BIRD {{ name = \"{self.name}\";  weight = {self.weight};  does_migrate = {self.does_migrate}; metric = {self.get_metric()} }}"

class Fish(Father_animal):
    obit = ["ozero", "reka", "more"]

    def __init__(self, name: str, weight: int, habitat: int):
        super().__init__(name, weight)
        if 1 <= habitat <= len(self.obit):
            self.habitat = self.obit[habitat - 1]
        else:
            raise Exception()

    def to_string(self) -> str:
        return f"fish {{ name = \"{self.name}\"; weight = {self.weight}; habitat = {self.habitat}; metric = {self.get_metric()} }}"
