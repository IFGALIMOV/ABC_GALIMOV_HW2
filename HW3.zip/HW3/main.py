
from random import randint
from All_animals import Zver, Fish, Bird
from Father_of_all_animals import Father_animal
import sys

def making_some_animals(index) -> Father_animal:
    animal_type = randint(0, 2)
    if animal_type == 0:
        return Zver(str(index), randint(1, 100), Zver.food_sources[randint(0, 3)])
    elif animal_type == 2:
        return Fish(str(index), randint(1, 100), Fish.obit[randint(0, 2)])
    elif animal_type == 1:
        return Bird(str(index), randint(1, 100), bool(randint(0, 1)))
    else:
        raise Exception(f"Unknown creature type at index {index}.")


def get_from_file(filename: str) -> list:
    Zvers = []
    with open(filename, "r") as file:
        for line in file:
            x = line.split()
            if int(x[2]) == 1:
                Zvers.append(Zver(x[0], int(x[1]), int(x[3])))
            elif int(x[2]) == 2:
                Zvers.append(Bird(x[0], int(x[1]), x[3] != "0"))
            elif int(x[2]) == 3:
                Zvers.append(Fish(x[0], int(x[1]), int(x[3])))
            else:
                raise Exception("Unknown creature.")

    return Zvers


def making(count: int) -> list:
    if count > 10000:
        count = 10000
    animals = []
    for i in range(count):
        animals.append(making_some_animals(i))
    return animals


def merge_sort(x):

    if len(x) < 2:return x

    result,mid = [],int(len(x)/2)

    y = merge_sort(x[:mid])
    z = merge_sort(x[mid:])

    while (len(y) > 0) and (len(z) > 0):
            if y[0] > z[0]:result.append(z.pop(0))
            else:result.append(y.pop(0))

    result.extend(y+z)
    return result

def OUTPUT_writing(filename: str, items: list, append: bool):
    try:
        if append:
            file = open(filename, "a")
            file.write(f"Sorted data contains {len(items)} elements:\n")
        else:
            file = open(filename, "w")
            file.write(f"Original data contains {len(items)} elements:\n")

        for item in items:
            file.write(item.to_string() + "\n")
        file.write("\n")

    except Exception as e:
        raise e

    finally:
        file.close()



if __name__ == '__main__':

    if len(sys.argv) > 4 or len(sys.argv) < 4:
        print("Program STOP!!!")
        sys.exit()
    args = sys.argv
    if args[1] == '-f':
        creatures = get_from_file(args[2])
    elif args[1] == '-r':
        creatures = making(int(args[2]))
    else:
        raise Exception("Incorrect input")

    output_file = args[3]
    print("Animals was made")
    OUTPUT_writing(output_file, creatures, False)
    print("Original animals was made")
    merge_sort(creatures)
    print("Animals was sorted")
    OUTPUT_writing(output_file, creatures, True)
    print("Sorted animals in txt file - complete")

if __name__ == '__main__':
    if len(sys.argv) != 4:
        print("Could not parse input.")
        sys.exit(101)

    # Parsing command line arguments.
    args = sys.argv
    try:
        if args[1] == '-r':
            creatures = making(int(args[2]))

        elif args[1] == '-f':
            creatures = get_from_file(args[2])
        else:
            raise Exception("Incorrect")
    except Exception as e:
        print(str(e))

    output_file = args[3]
    print("OK")

    OUTPUT_writing(output_file, creatures, False)
    print("Animals was made\n")

    merge_sort(creatures)
    print("Merge SORT!\n")

    OUTPUT_writing(output_file, creatures, True)
    print("Animals was written in file")

